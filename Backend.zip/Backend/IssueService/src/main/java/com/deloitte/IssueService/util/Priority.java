package com.deloitte.IssueService.util;

public enum Priority {
    HIGH,
    MEDIUM,
    LOW
}
