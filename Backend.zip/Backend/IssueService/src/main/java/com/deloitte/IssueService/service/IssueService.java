package com.deloitte.IssueService.service;

import com.deloitte.IssueService.dto.IssueRequestDto;
import com.deloitte.IssueService.dto.IssueResponseDto;

import java.util.List;

public interface IssueService {

    IssueResponseDto createIssue(IssueRequestDto issueRequestDto);

    IssueResponseDto getIssueById(Integer issueId);

    List<IssueResponseDto> getAllIssues();

    IssueResponseDto updateIssue(
            Integer issueId,
            IssueRequestDto issueRequestDto
    );

    void deleteIssueById(Integer issueId);

    List<IssueResponseDto> getIssuesByProjectId(Integer projectId);

    List<IssueResponseDto> getIssuesByAssigneeId(Integer assigneeId);

    List<IssueResponseDto> getIssuesByCreater(Integer createdBy);
}