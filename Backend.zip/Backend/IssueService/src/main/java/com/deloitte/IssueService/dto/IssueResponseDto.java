package com.deloitte.IssueService.dto;

import com.deloitte.IssueService.util.Priority;
import com.deloitte.IssueService.util.Status;
import com.deloitte.IssueService.util.Type;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class IssueResponseDto {

    private Integer id;

    private LocalDate createdOn;

    private LocalDate lastUpdated;

    private Integer project;

    private String description;

    private String summary;

    private Priority priority;

    private Status status;

    private Integer createdBy;

    private Integer assignee;

    private String sprint;

    private Integer storyPoint;

    private String tags;

    private Type type;
}