package com.deloitte.IssueService.client;

import com.deloitte.IssueService.dto.UserResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "UserService")
public interface UserServiceClient {

    @GetMapping("/api/users/{userId}")
    UserResponseDto getUserById(@PathVariable Integer userId);
}