package com.deloitte.IssueService.entity;

import com.deloitte.IssueService.util.Priority;
import com.deloitte.IssueService.util.Status;
import com.deloitte.IssueService.util.Type;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Issue {

    @Id
    @TableGenerator(name = "issue_gen", table = "issue_seq", pkColumnName = "issue_key", valueColumnName = "issue_val", initialValue = 300, allocationSize = 1)
    @GeneratedValue(generator = "issue_gen")
    private Integer id;


    private LocalDate createdOn;

    private LocalDate lastUpdated;

    private Integer project; // project description

    private String description;

    private String summary;

    @Enumerated(EnumType.STRING)
    private Priority priority;

    @Enumerated(EnumType.STRING)
    private Status status;

    private Integer createdBy; // user description

    private Integer assignee;

    private String sprint;

    private Integer storyPoint;

    private String tags;

    @Enumerated(EnumType.STRING)
    private Type type;

}
