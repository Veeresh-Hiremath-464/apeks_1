package com.deloitte.IssueService.repository;

import com.deloitte.IssueService.entity.Issue;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Arrays;
import java.util.List;

public interface IssueRepository extends JpaRepository<Issue, Integer> {
    List<Issue> findByProject(Integer projectId);
    List<Issue> findByAssignee(Integer assigneeId);

    List<Issue> findByCreatedBy(Integer createdBy);
}