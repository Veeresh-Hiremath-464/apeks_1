package com.deloitte.IssueService.dto;

import com.deloitte.IssueService.util.Priority;
import com.deloitte.IssueService.util.Status;
import com.deloitte.IssueService.util.Type;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class IssueRequestDto {

    @NotNull(message = "Project ID cannot be empty")
    private Integer project;

    @NotBlank(message = "Summary cannot be empty")
    @Size(
            min = 2,
            max = 200,
            message = "Summary must be between 2 and 200 characters"
    )
    private String summary;

    @Size(
            max = 2000,
            message = "Description cannot exceed 2000 characters"
    )
    private String description;

    @NotNull(message = "Priority cannot be empty")
    private Priority priority;

    @NotNull(message = "Status cannot be empty")
    private Status status;

    @NotNull(message = "Created By User ID cannot be empty")
    private Integer createdBy;

    @NotNull(message = "Assignee User ID cannot be empty")
    private Integer assignee;

    @NotNull(message = "Sprint cannot be empty")
    private String sprint;

    @NotNull(message = "Story point cannot be empty")
    @Min(
            value = 1,
            message = "Story point must be at least 1"
    )
    private Integer storyPoint;

    @NotBlank(message = "Tags cannot be empty")
    private String tags;

    @NotNull(message = "Issue type cannot be empty")
    private Type type;
}