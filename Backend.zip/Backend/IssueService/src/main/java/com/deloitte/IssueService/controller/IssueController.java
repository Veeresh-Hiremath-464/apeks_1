package com.deloitte.IssueService.controller;

import com.deloitte.IssueService.dto.IssueRequestDto;
import com.deloitte.IssueService.dto.IssueResponseDto;
import com.deloitte.IssueService.service.IssueService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class IssueController {

    private final IssueService issueService;

    public IssueController(IssueService issueService) {
        this.issueService = issueService;
    }

    @PostMapping("/issues")
    public ResponseEntity<IssueResponseDto> createIssue(@Valid @RequestBody IssueRequestDto issueRequestDto) {

        IssueResponseDto responseDto = issueService.createIssue(issueRequestDto);

        return new ResponseEntity<>(responseDto, HttpStatus.CREATED);
    }

    @GetMapping("/issues/{issueId}")
    public ResponseEntity<IssueResponseDto> getIssueById(@PathVariable Integer issueId) {

        IssueResponseDto responseDto = issueService.getIssueById(issueId);

        return ResponseEntity.ok(responseDto);
    }

    @GetMapping("/issues")
    public ResponseEntity<List<IssueResponseDto>> getAllIssues() {

        List<IssueResponseDto> issues = issueService.getAllIssues();

        return ResponseEntity.ok(issues);
    }

    @PutMapping("/issues/{issueId}")
    public ResponseEntity<IssueResponseDto> updateIssue(@PathVariable Integer issueId, @Valid @RequestBody IssueRequestDto issueRequestDto) {

        IssueResponseDto responseDto = issueService.updateIssue(issueId, issueRequestDto);

        return ResponseEntity.ok(responseDto);
    }

    @DeleteMapping("/issues/{issueId}")
    public ResponseEntity<String> deleteIssueById(@PathVariable Integer issueId) {

        issueService.deleteIssueById(issueId);

        return ResponseEntity.ok("Issue Deleted Successfully");
    }

//    interservices

    @GetMapping("/issues/assignee/{assigneeId}")
    public ResponseEntity<List<IssueResponseDto>> getIssuesByAssigneeId(@PathVariable Integer assigneeId) {

        List<IssueResponseDto> issues = issueService.getIssuesByAssigneeId(assigneeId);

        return ResponseEntity.ok(issues);
    }

    @GetMapping("/issues/project/{projectId}")
    public ResponseEntity<List<IssueResponseDto>> getIssuesByProjectId(
            @PathVariable Integer projectId) {

        //handle exception if no projects are present
        List<IssueResponseDto> issues =
                issueService.getIssuesByProjectId(projectId);

        return ResponseEntity.ok(issues);
    }

    @GetMapping("/issues/owner/{createdBy}")
    public ResponseEntity<List<IssueResponseDto>> getIssuesByCreater(@PathVariable Integer createdBy){
        List<IssueResponseDto> requiredIssues = issueService.getIssuesByCreater(createdBy);

        return ResponseEntity.ok(requiredIssues);
    }
}