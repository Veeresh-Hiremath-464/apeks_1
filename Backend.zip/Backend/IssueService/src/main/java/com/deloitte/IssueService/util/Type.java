package com.deloitte.IssueService.util;

public enum Type {
    PROJECT_OWNER,
    ASSIGNEE
}
