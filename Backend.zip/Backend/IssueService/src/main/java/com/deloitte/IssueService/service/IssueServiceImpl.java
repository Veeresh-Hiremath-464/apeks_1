package com.deloitte.IssueService.service;

import com.deloitte.IssueService.client.ProjectServiceClient;
import com.deloitte.IssueService.client.UserServiceClient;
import com.deloitte.IssueService.dto.IssueRequestDto;
import com.deloitte.IssueService.dto.IssueResponseDto;
import com.deloitte.IssueService.entity.Issue;
import com.deloitte.IssueService.exception.ResourceNotFoundException;
import com.deloitte.IssueService.repository.IssueRepository;
import com.deloitte.IssueService.util.Status;
import feign.FeignException;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class IssueServiceImpl implements IssueService {

    private final IssueRepository issueRepository;
    private final ModelMapper modelMapper;
    private final UserServiceClient userServiceClient;
    private final ProjectServiceClient projectServiceClient;

    public IssueServiceImpl(IssueRepository issueRepository, ModelMapper modelMapper, UserServiceClient userServiceClient, ProjectServiceClient projectServiceClient) {

        this.issueRepository = issueRepository;
        this.modelMapper = modelMapper;
        this.userServiceClient = userServiceClient;
        this.projectServiceClient = projectServiceClient;
    }

    @Override
    public IssueResponseDto createIssue(IssueRequestDto issueRequestDto) {
    	
    	try {
    		projectServiceClient.getProjectById(issueRequestDto.getProject());
        } catch (FeignException.NotFound e) {
            throw new ResourceNotFoundException("No Project Found with Project Id: " + issueRequestDto.getProject());
        }
    	
    	try {
            userServiceClient.getUserById(issueRequestDto.getCreatedBy());
        } catch (FeignException.NotFound e) {
            throw new ResourceNotFoundException("No User Found with User Id: " + issueRequestDto.getCreatedBy());
        }
    	
    	try {
            userServiceClient.getUserById(issueRequestDto.getAssignee());
    	}catch (FeignException.NotFound e) {
            throw new ResourceNotFoundException("No User Found with User Id: " + issueRequestDto.getAssignee());
        }

    	

        Issue issue = modelMapper.map(issueRequestDto, Issue.class);

        issue.setCreatedOn(LocalDate.now());
        issue.setLastUpdated(LocalDate.now());

        if (issue.getStatus() == null) {
            issue.setStatus(Status.STARTED);
        }

        Issue savedIssue = issueRepository.save(issue);

        return modelMapper.map(savedIssue, IssueResponseDto.class);
    }

    @Override
    public IssueResponseDto getIssueById(Integer issueId) {

        Issue issue = issueRepository.findById(issueId).orElseThrow(() -> new ResourceNotFoundException("No Issue Found with Issue Id: " + issueId));

        return modelMapper.map(issue, IssueResponseDto.class);
    }

    @Override
    public List<IssueResponseDto> getAllIssues() {

        return issueRepository.findAll().stream().map(issue -> modelMapper.map(issue, IssueResponseDto.class)).toList();
    }

    @Override
    public IssueResponseDto updateIssue(Integer issueId, IssueRequestDto issueRequestDto) {

        Issue issue = issueRepository.findById(issueId).orElseThrow(() -> new ResourceNotFoundException("No Issue Found with Issue Id: " + issueId));

        modelMapper.map(issueRequestDto, issue);

        issue.setLastUpdated(LocalDate.now());

        Issue updatedIssue = issueRepository.save(issue);

        return modelMapper.map(updatedIssue, IssueResponseDto.class);
    }

    @Override
    public void deleteIssueById(Integer issueId) {

        Issue issue = issueRepository.findById(issueId).orElseThrow(() -> new ResourceNotFoundException("No Issue Found with Issue Id: " + issueId));

        issueRepository.delete(issue);
    }

//    interservoce communication
    @Override
    public List<IssueResponseDto> getIssuesByProjectId(Integer projectId) {

        try {
            projectServiceClient.getProjectById(projectId);
        } catch (FeignException.NotFound e) {
            throw new ResourceNotFoundException("No Project Found with Project Id: " + projectId);
        }

        return issueRepository.findByProject(projectId).stream().map(issue -> modelMapper.map(issue, IssueResponseDto.class)).toList();
    }

    @Override
    public List<IssueResponseDto> getIssuesByAssigneeId(Integer assigneeId) {
        try {
            userServiceClient.getUserById(assigneeId);
        } catch (FeignException.NotFound e) {
            throw new ResourceNotFoundException("No User Found with User Id: " + assigneeId);
        }

        return issueRepository.findByAssignee(assigneeId).stream().map(issue -> modelMapper.map(issue, IssueResponseDto.class)).toList();
    }

    @Override
    public List<IssueResponseDto> getIssuesByCreater(Integer createdBy) {
        try {
            userServiceClient.getUserById(createdBy);
        } catch (FeignException.NotFound e) {
            throw new ResourceNotFoundException("No User Found with User Id: " + createdBy);
        }

        return issueRepository.findByCreatedBy(createdBy).stream().map(issues -> modelMapper.map(issues, IssueResponseDto.class)).toList();
    }
}