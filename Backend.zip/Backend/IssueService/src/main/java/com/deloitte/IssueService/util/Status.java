package com.deloitte.IssueService.util;

public enum Status {
    STARTED,
    PENDING,
    FINISHED
}
