package com.deloitte.IssueService.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectResponseDto {

    private LocalDate endDate;

    private Integer productOwner;

    private LocalDate startDate;

    private Integer id;

    private String projectName;
}
