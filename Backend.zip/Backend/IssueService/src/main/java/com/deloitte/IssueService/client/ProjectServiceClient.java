package com.deloitte.IssueService.client;

import com.deloitte.IssueService.dto.ProjectResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "ProjectService")
public interface ProjectServiceClient {

    @GetMapping("/api/projects/{projectId}")
    ProjectResponseDto getProjectById(@PathVariable Integer projectId);
}
