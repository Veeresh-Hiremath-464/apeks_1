package com.deloitte.ProjectService.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.deloitte.ProjectService.dto.UserResponseDto;

@FeignClient(name = "UserService")
public interface UserServiceClient {
	
	@GetMapping("/api/users/{userId}")
	UserResponseDto getUserById(@PathVariable Integer userId);
	
}
