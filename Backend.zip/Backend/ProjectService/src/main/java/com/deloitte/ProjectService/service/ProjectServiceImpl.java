package com.deloitte.ProjectService.service;

import com.deloitte.ProjectService.client.IssueServiceClient;
import com.deloitte.ProjectService.client.UserServiceClient;
import com.deloitte.ProjectService.dto.IssueResponseDto;
import com.deloitte.ProjectService.dto.ProjectRequestDto;
import com.deloitte.ProjectService.dto.ProjectResponseDto;
import com.deloitte.ProjectService.dto.UserResponseDto;
import com.deloitte.ProjectService.entity.Project;
import com.deloitte.ProjectService.exception.ResourceAlreadyExistsException;
import com.deloitte.ProjectService.exception.ResourceNotFoundException;
import com.deloitte.ProjectService.repository.ProjectRepository;

import feign.FeignException;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProjectServiceImpl implements ProjectService {

	// Rest Template implementation

	private final RestTemplate restTemplate;

	private final ProjectRepository projectRepository;
	private final IssueServiceClient issueServiceClient;
	private final UserServiceClient userServiceClient;

	private final ModelMapper modelMapper;

	public ProjectServiceImpl(ProjectRepository projectRepository, ModelMapper modelMapper,
			IssueServiceClient issueServiceClient, UserServiceClient userServiceClient, RestTemplate restTemplate) {
		this.projectRepository = projectRepository;
		this.modelMapper = modelMapper;
		this.issueServiceClient = issueServiceClient;
		this.userServiceClient = userServiceClient;

		this.restTemplate = restTemplate;
	}

	@Override
	public ProjectResponseDto getProjectById(Integer projectId) {
		Project project = projectRepository.findById(projectId)
				.orElseThrow(() -> new ResourceNotFoundException("No Project Found with Project Id: " + projectId));
		ProjectResponseDto projectDto = modelMapper.map(project, ProjectResponseDto.class);
		return projectDto;
	}

	@Override
	public ProjectResponseDto updateProject(Integer projectId, ProjectRequestDto projectRequestDto) {

		Project project = projectRepository.findById(projectId)
				.orElseThrow(() -> new ResourceNotFoundException("No Project Found with Project Id: " + projectId));

		modelMapper.map(projectRequestDto, project);
		Project savedProject = projectRepository.save(project);

		return modelMapper.map(savedProject, ProjectResponseDto.class);
	}

	@Override
	public void deleteProjectById(Integer projectId) {
		Project requiredProject = projectRepository.findById(projectId)
				.orElseThrow(() -> new ResourceNotFoundException("No Project Found with Project Id: " + projectId));

		projectRepository.delete(requiredProject);
	}

	@Override
	public List<ProjectResponseDto> getAllProject() {
		List<Project> allProjectList = projectRepository.findAll();
		List<ProjectResponseDto> allProjectDtoList = new ArrayList<>();

		for (Project p : allProjectList) {
			ProjectResponseDto tempDto = modelMapper.map(p, ProjectResponseDto.class);
			allProjectDtoList.add(tempDto);
		}

		return allProjectDtoList;
	}

	@Override
	public ProjectResponseDto createProject(ProjectRequestDto newProject) {
		if (projectRepository.existsByProjectName(newProject.getProjectName())) {
			throw new ResourceAlreadyExistsException("Project Already Exists");
		}

		try {
//			 feign client
            userServiceClient.getUserById(newProject.getProjectOwner());

//			String url = "http://localhost:8081/api/users/{userId}";
//
//			UserResponseDto user = restTemplate.getForObject(url, UserResponseDto.class, newProject.getProjectOwner());
//
//			if (user == null) {
//				throw new ResourceNotFoundException("No User Found with User Id: " + newProject.getProjectOwner());
//			}

		} catch (FeignException.NotFound e) {
			throw new ResourceNotFoundException("No User Found with User Id: " + newProject.getProjectOwner());
		}

		Project project = modelMapper.map(newProject, Project.class);

		Project storedProject = projectRepository.save(project);

		return modelMapper.map(storedProject, ProjectResponseDto.class);
	}

	@Override
	public List<IssueResponseDto> getIssueByProjectId(Integer projectId) {
		if (!projectRepository.existsById(projectId)) {
			throw new ResourceNotFoundException("Project with this Id: " + projectId + " Does not exists!");
		}

		return issueServiceClient.getIssuesByProjectId(projectId);
	}

	@Override
	public List<IssueResponseDto> getIssueByProjectName(String projectName) {
		Project requiredProject = projectRepository.findByProjectName(projectName)
				.orElseThrow(() -> new ResourceNotFoundException("No Project Found with Project Name: " + projectName));

		List<IssueResponseDto> reqIssue = issueServiceClient.getIssuesByProjectId(requiredProject.getId());

		return reqIssue;
	}

	@Override
	public List<ProjectResponseDto> getProjectByOwnerId(Integer ownerId) {
		List<Project> requiredProjects = projectRepository.findByProjectOwner(ownerId);
		List<ProjectResponseDto> projectResponseDtos = new ArrayList<>();

		for (Project proj : requiredProjects) {
			projectResponseDtos.add(modelMapper.map(proj, ProjectResponseDto.class));
		}

		return projectResponseDtos;
	}
}
