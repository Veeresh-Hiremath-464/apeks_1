package com.deloitte.ProjectService.dto;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectRequestDto {

    @NotNull(message = "End Date cannot be empty")
    private LocalDate endDate;

    @NotNull(message = "Project Owner cannot be empty")
    private Integer projectOwner;

    @NotNull(message = "Start Date cannot be empty")
    private LocalDate startDate;

    @NotBlank(message = "Project Name cannot be empty")
    @Size(min = 2, max = 60, message = "Project Name should not be null")
    private String projectName;

    @AssertTrue(message = "Start Date must be before End Date")
    private boolean isValidDateRange(){
        if (startDate == null || endDate == null) return true;
        return startDate.isBefore(endDate);
    }
}
