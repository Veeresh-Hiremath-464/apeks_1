package com.deloitte.ProjectService.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectResponseDto {

    private LocalDate endDate;

    private Integer projectOwner;

    private LocalDate startDate;

    private Integer id;

    private String projectName;
}
