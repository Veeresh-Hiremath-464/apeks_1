package com.deloitte.ProjectService.entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "project")
public class Project {

    @Id
    @TableGenerator(
            name = "proj_gen",
            table = "proj_seq",
            pkColumnName = "proj_key",
            pkColumnValue = "PROJECT",
            valueColumnName = "proj_value",
            initialValue = 200,
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.TABLE,
            generator = "proj_gen"
    )
    private Integer id;

    @Column(nullable = false)
    private LocalDate endDate;

    @Column(nullable = false)
    private Integer projectOwner;

    @Column(nullable = false)
    private LocalDate startDate;

    @Column(nullable = false, unique = true, length = 120)
    private String projectName;

    // Getters and Setters

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public Integer getProjectOwner() {
        return projectOwner;
    }

    public void setProjectOwner(Integer productOwner) {
        this.projectOwner = productOwner;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }
}
