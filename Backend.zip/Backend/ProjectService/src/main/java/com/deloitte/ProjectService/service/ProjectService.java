package com.deloitte.ProjectService.service;

import com.deloitte.ProjectService.dto.IssueResponseDto;
import com.deloitte.ProjectService.dto.ProjectRequestDto;
import com.deloitte.ProjectService.dto.ProjectResponseDto;

import java.util.List;
import java.util.Optional;

public interface ProjectService {
    ProjectResponseDto getProjectById(Integer projectId);

    ProjectResponseDto updateProject(Integer projectId, ProjectRequestDto projectRequestDto);

    void deleteProjectById(Integer projectId);

    List<ProjectResponseDto> getAllProject();

    ProjectResponseDto createProject(ProjectRequestDto newProject);

    List<IssueResponseDto> getIssueByProjectId(Integer projectId);

    List<IssueResponseDto> getIssueByProjectName(String projectName);

    List<ProjectResponseDto> getProjectByOwnerId(Integer ownerId);
}
