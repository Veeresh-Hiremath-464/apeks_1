package com.deloitte.ProjectService.dto;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserResponseDto {
    private Integer userId;
    private String email;
    private String name;
    private String profile;
    private String role;
}