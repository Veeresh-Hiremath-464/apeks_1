package com.deloitte.ProjectService.controller;

import com.deloitte.ProjectService.dto.IssueResponseDto;
import com.deloitte.ProjectService.dto.ProjectRequestDto;
import com.deloitte.ProjectService.dto.ProjectResponseDto;
import com.deloitte.ProjectService.repository.ProjectRepository;
import com.deloitte.ProjectService.service.ProjectService;
import com.deloitte.ProjectService.service.ProjectServiceImpl;
import jakarta.validation.Valid;
import org.apache.coyote.Response;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ProjectController {

    private final ProjectService projectServiceImpl;

    public ProjectController(ProjectService projectServiceImpl){
        this.projectServiceImpl = projectServiceImpl;
    }

    @GetMapping("/")
    public String getRoot(){
        return "Welcome to the root";
    }

    @GetMapping("/projects/{projectId}")
    public ResponseEntity<ProjectResponseDto> getProjectById(@PathVariable Integer projectId){
        ProjectResponseDto responseDto = projectServiceImpl.getProjectById(projectId);
        return new ResponseEntity<>(responseDto,HttpStatus.OK);
    }

    @PutMapping("/projects/{projectId}")
    public ResponseEntity<ProjectResponseDto> updateProject(@PathVariable Integer projectId, @Valid @RequestBody ProjectRequestDto projectRequestDto){
        ProjectResponseDto responseDto = projectServiceImpl.updateProject(projectId, projectRequestDto);
        return new ResponseEntity<>(responseDto, HttpStatus.ACCEPTED);
    }

    @DeleteMapping("/projects/{projectId}")
    public ResponseEntity<String> deleteUserById(@PathVariable Integer projectId){
        projectServiceImpl.deleteProjectById(projectId);

        return new ResponseEntity<>(
                "Project Deleted Successfully",
                HttpStatus.OK
        );
    }

    @GetMapping("/projects")
    public ResponseEntity<List<ProjectResponseDto>> getAllProjects(){
        List<ProjectResponseDto> allProjectList = projectServiceImpl.getAllProject();
        return new ResponseEntity<>(allProjectList, HttpStatus.OK);
    }

    @PostMapping("/projects")
    public ResponseEntity<ProjectResponseDto> createProject(@Valid @RequestBody ProjectRequestDto newProject){
        ProjectResponseDto responseDto = projectServiceImpl.createProject(newProject);

        return new ResponseEntity<>(responseDto, HttpStatus.CREATED);
    }

    @GetMapping("/projects/owner/{ownerId}")
    public ResponseEntity<List<ProjectResponseDto>> getProjectByOwnerId(@PathVariable Integer ownerId){
        List<ProjectResponseDto> requiredProjects = projectServiceImpl.getProjectByOwnerId(ownerId);

        return ResponseEntity.ok(requiredProjects);
    }

//    interservice

    @GetMapping("/projects/{projectId}/issues")
    public ResponseEntity<List<IssueResponseDto>> getIssueByProjectId(@PathVariable Integer projectId){
        List<IssueResponseDto> requiredIssues = projectServiceImpl.getIssueByProjectId(projectId);

        return ResponseEntity.ok(requiredIssues);
    }

    @GetMapping("/projects/projectname/{projectName}/issues")
    public ResponseEntity<List<IssueResponseDto>> getIssueByProjectId(@PathVariable String projectName){
        List<IssueResponseDto> requiredIssues = projectServiceImpl.getIssueByProjectName(projectName);

        return ResponseEntity.ok(requiredIssues);
    }


}
