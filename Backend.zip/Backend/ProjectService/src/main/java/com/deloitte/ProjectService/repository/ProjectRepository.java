package com.deloitte.ProjectService.repository;

import com.deloitte.ProjectService.entity.Project;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ProjectRepository extends JpaRepository<Project, Integer> {

    boolean existsByProjectName(String projectName);

    //unique name constraint
    Optional<Project> findByProjectName(String projectName);

    List<Project> findByProjectOwner(Integer ownerId);
}
