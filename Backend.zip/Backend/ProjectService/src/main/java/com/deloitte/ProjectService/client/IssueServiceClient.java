package com.deloitte.ProjectService.client;

import com.deloitte.ProjectService.dto.IssueResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "IssueService")
public interface IssueServiceClient {

    @GetMapping("/api/issues/project/{projectId}")
    List<IssueResponseDto> getIssuesByProjectId(@PathVariable Integer projectId);


}
