package com.deloitte.ProjectService.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.hibernate.metamodel.mapping.internal.MappingModelCreationProcess;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class ProjectConfig {
    @Bean
    public ModelMapper modelMapper(){
        return new ModelMapper();
    }

    @Bean
    public OpenAPI openAPI() {
        OpenAPI openAPI = new OpenAPI();
        return openAPI.info(new Info().title("Open API Documentation").description("Open API Documentation for User Microservice").version("1.0"));
    }
    
    @Bean RestTemplate getRestTemplate() {
    	return new RestTemplate();
    }
}
