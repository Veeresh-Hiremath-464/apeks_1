package com.deloitte.UserService.exception;

public class GenericErrorException extends Exception{
    public GenericErrorException(String msg){
        super(msg);
    }
}
