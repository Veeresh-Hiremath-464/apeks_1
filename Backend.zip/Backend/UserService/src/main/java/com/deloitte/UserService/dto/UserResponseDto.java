package com.deloitte.UserService.dto;

import com.deloitte.UserService.util.Role;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserResponseDto {
    private Integer userId;
    private String email;
    private String name;
    private String profile;
    private Role role;
}