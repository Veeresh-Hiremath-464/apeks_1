package com.deloitte.UserService.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
public class IssueResponseDto {

    private Integer id;

    private LocalDate createdOn;

    private LocalDate lastUpdated;

    private Integer project;

    private String description;

    private String summary;

    private String priority;

    private String status;

    private Integer createdBy;

    private Integer assignee;

    private String sprint;

    private Integer storyPoint;

    private String tags;

    private String type;
}