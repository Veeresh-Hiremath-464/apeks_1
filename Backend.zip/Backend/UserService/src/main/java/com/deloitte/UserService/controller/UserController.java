package com.deloitte.UserService.controller;

import com.deloitte.UserService.dto.IssueResponseDto;
import com.deloitte.UserService.dto.LoginRequest;
import com.deloitte.UserService.dto.UserRequestDto;
import com.deloitte.UserService.dto.UserResponseDto;
import com.deloitte.UserService.service.UserServiceImpl;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class UserController {

	private final UserServiceImpl userService;

	public UserController(UserServiceImpl userService) {
		this.userService = userService;
	}

	@GetMapping("/")
	public String getRoot() {
		return "Welcome to the Root";
	}

	@GetMapping("/users")
	public ResponseEntity<List<UserResponseDto>> getAllUsers() {
		return new ResponseEntity<>(userService.getAllUser(), HttpStatus.OK);
	}

	@PostMapping("/users")
	public ResponseEntity<UserResponseDto> createUser(@Valid @RequestBody UserRequestDto newUser) {
		return new ResponseEntity<>(userService.createUser(newUser), HttpStatus.CREATED);
	}

	@GetMapping("/users/{userId}")
	public ResponseEntity<UserResponseDto> getUserById(@PathVariable Integer userId) {
		return new ResponseEntity<>(userService.getUserById(userId), HttpStatus.OK);
	}

	@PostMapping("/login")
	public ResponseEntity<String> login(@Valid @RequestBody LoginRequest request) {

		return ResponseEntity.ok(userService.login(request));
	}

	// interservice

	@GetMapping("/users/{userId}/issues")
	public ResponseEntity<List<IssueResponseDto>> getIssuesByUserId(@PathVariable Integer userId) {

		List<IssueResponseDto> issues = userService.getIssuesByUserId(userId);

		return ResponseEntity.ok(issues);
	}

	@GetMapping("/users/username/{username}/issues")
	public ResponseEntity<List<IssueResponseDto>> getIssuesByUsername(@PathVariable String username) {

		List<IssueResponseDto> issues = userService.getIssuesByUsername(username);

		return ResponseEntity.ok(issues);
	}

}
