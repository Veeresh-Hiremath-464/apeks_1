package com.deloitte.UserService.entity;
import com.deloitte.UserService.util.Role;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "user")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @TableGenerator(name = "user_gen", table = "user_seq", pkColumnName = "user_key", valueColumnName = "user_val", initialValue = 100, allocationSize = 1)
    @GeneratedValue(generator = "user_gen")
    private Integer userId;

    @Column(nullable = false, unique = true, length = 150)
    private String email;

    @Column(nullable = false, unique = true, length = 150)
    private String name;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String profile;

    @Enumerated(EnumType.STRING)
    private Role role;
}