package com.deloitte.UserService.client;

import com.deloitte.UserService.dto.IssueResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "IssueService")
public interface IssueServiceClient {

    @GetMapping("/api/issues/assignee/{assigneeId}")
    List<IssueResponseDto> getIssuesByAssigneeId(@PathVariable Integer assigneeId);

}