package com.deloitte.UserService.service;

import com.deloitte.UserService.dto.IssueResponseDto;
import com.deloitte.UserService.dto.UserRequestDto;
import com.deloitte.UserService.dto.UserResponseDto;
import jakarta.validation.Valid;

import java.util.List;

public interface UserService {
    UserResponseDto createUser(@Valid UserRequestDto newUser);

    UserResponseDto getUserById(Integer userId);

    List<IssueResponseDto> getIssuesByUserId(Integer userId);

    List<IssueResponseDto> getIssuesByUsername(String username);
}
