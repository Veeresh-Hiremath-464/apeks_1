package com.deloitte.UserService.service;

import com.deloitte.UserService.client.IssueServiceClient;
import com.deloitte.UserService.dto.IssueResponseDto;
import com.deloitte.UserService.dto.LoginRequest;
import com.deloitte.UserService.dto.UserRequestDto;
import com.deloitte.UserService.dto.UserResponseDto;
import com.deloitte.UserService.entity.User;
import com.deloitte.UserService.exception.ResourceAlreadyExistsException;
import com.deloitte.UserService.exception.ResourceNotFoundException;
import com.deloitte.UserService.repository.UserRepository;

import jakarta.validation.Valid;

import org.jspecify.annotations.Nullable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

	private final UserRepository userRepository;
	private final IssueServiceClient issueServiceClient;

	public UserServiceImpl(UserRepository userRepository, IssueServiceClient issueServiceClient) {
		this.userRepository = userRepository;
		this.issueServiceClient = issueServiceClient;
	}

	@Override
	public UserResponseDto createUser(UserRequestDto newUser) {
		if (userRepository.existsByEmail(newUser.getEmail())) {
			throw new ResourceAlreadyExistsException("User Already Exists With Email: " + newUser.getEmail());
		}

		if (userRepository.existsByName(newUser.getName())) {
			throw new ResourceAlreadyExistsException("User Already Exists With Username: " + newUser.getName());
		}

		User user = new User();
		user.setName(newUser.getName());
		user.setPassword(newUser.getPassword());
		user.setEmail(newUser.getEmail());
		user.setProfile(newUser.getProfile());
		user.setRole(newUser.getRole());

		User storedUser = userRepository.save(user);

		return mapToResponseDto(storedUser);
	}

	@Override
	public UserResponseDto getUserById(Integer userId) {
		User requiredUser = userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

		return mapToResponseDto(requiredUser);
	}

	public List<UserResponseDto> getAllUser() {
		List<User> users = userRepository.findAll();
		List<UserResponseDto> userDto = new ArrayList<>();

		for (User currUser : users) {
			UserResponseDto userResponseDto = new UserResponseDto();
			userResponseDto.setUserId(currUser.getUserId());
			userResponseDto.setEmail(currUser.getEmail());
			userResponseDto.setName(currUser.getName());
			userResponseDto.setProfile(currUser.getProfile());
			userResponseDto.setRole(currUser.getRole());

			userDto.add(userResponseDto);
		}

		return userDto;
	}

	private UserResponseDto mapToResponseDto(User user) {

		UserResponseDto responseDto = new UserResponseDto();

		responseDto.setUserId(user.getUserId());
		responseDto.setName(user.getName());
		responseDto.setEmail(user.getEmail());
		responseDto.setProfile(user.getProfile());
		responseDto.setRole(user.getRole());

		return responseDto;
	}

	// interservice communication
	@Override
	public List<IssueResponseDto> getIssuesByUserId(Integer userId) {

		userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

		return issueServiceClient.getIssuesByAssigneeId(userId);
	}

	// assumption is that names are unique and hence we get single user for
	// searching with name
	@Override
	public List<IssueResponseDto> getIssuesByUsername(String username) {

		User reqUser = userRepository.getUserByName(username)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with name: " + username));
//        List<Integer> reqUserId = new ArrayList<>();
//
//        for(User user: reqUsers){
//            Integer id = user.getUserId();
//            reqUserId.add(id);
//        }

		return issueServiceClient.getIssuesByAssigneeId(reqUser.getUserId());
	}

	public String login(@Valid LoginRequest request) {
		
		User requiredUser = userRepository.findByEmail(request.getEmail())
				.orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + request.getEmail()));

		if(!requiredUser.getPassword().equals(request.getPassword())) {
			throw new ResourceNotFoundException("User not found with password: " + request.getPassword());
		}
		
		if(!requiredUser.getRole().equals(request.getRole())) {
			throw new ResourceNotFoundException("User not found with role: " + request.getRole());
		}
		
		return "Login Successful and User Found";
	}
}
