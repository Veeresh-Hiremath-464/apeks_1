package com.deloitte.UserService.dto;

import com.deloitte.UserService.util.Role;
import jakarta.validation.constraints.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserRequestDto {
    @NotBlank(message = "Email cannot be empty")
    @Email(message = "User email structure invalid")
    private String email;

    @NotBlank(message = "Name cannot be empty")
    @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters")
    private String name;

    @NotBlank(message = "Password cannot be empty")
    @Size(min = 8, max = 20, message = "Password must be between 8 and 20 characters")
    private String password;

    @Size(max = 255, message = "Profile must not exceed 255 characters")
    private String profile;

    @NotNull(message = "Role cannot be empty")
//    @Pattern(regexp = "^(PROJECT_OWNER|ASSIGNEE)$", message = "Role must be PROJECT_OWNER or ASSIGNEE")
    private Role role;
}