package com.deloitte.UserService.repository;

import com.deloitte.UserService.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    @Override
    Optional<User> findById(Integer integer);
    boolean existsByEmail(String email);

    Optional<User> getUserByName(String name);
    
    boolean existsByName(String name);

    Optional<User> findByEmail(String email);
}
