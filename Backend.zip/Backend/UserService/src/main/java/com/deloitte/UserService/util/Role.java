package com.deloitte.UserService.util;

public enum Role {
    PROJECT_OWNER,
    ASSIGNEE
}
