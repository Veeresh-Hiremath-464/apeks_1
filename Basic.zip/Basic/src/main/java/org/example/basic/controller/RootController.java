package org.example.basic.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RootController {

    @GetMapping("/root")
    public String getRoot(){
        return "Welcome to the Root page";
    }

}
